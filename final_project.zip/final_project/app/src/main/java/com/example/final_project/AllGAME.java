package com.example.final_project;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.final_project.databinding.ActivityDataBaseBinding;

import java.util.ArrayList;

public class AllGAME extends AppCompatActivity {
    ActivityDataBaseBinding binding;

    MyDatabase myDB;
    ArrayList <ModelClass> list;
    RecyclerViewAdapter customAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityDataBaseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        myDB=new MyDatabase(AllGAME.this);
        storeDateInArrays();

        list = myDB.getAllGames();

        customAdapter=new RecyclerViewAdapter(AllGAME.this,list);
        binding.recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(),
                LinearLayoutManager.VERTICAL, false);
        binding.recyclerView.setLayoutManager(layoutManager);

        binding.recyclerView.setAdapter(customAdapter);


    }
    void storeDateInArrays(){
        Cursor cursor=myDB.readAllDate();
        if (cursor.getCount()==0){
            Toast.makeText(this, "NO DATA ..", Toast.LENGTH_SHORT).show();
        }else {
            myDB.getAllGames();
        }
    }
}